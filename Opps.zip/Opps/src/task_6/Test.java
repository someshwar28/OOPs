package task_6;

public class Test extends LargestNumberExample
{

	public static void main(String[] args)
	{
		LargestNumberExample l =new LargestNumberExample();
		                     l.LargestNumberOF3();
		                     l.LargestNumberOF4();
		                    // int key=3;
		                 /*    switch (key) 
		                     {
							case 1: 
							{
								l.LargestNumberOF3();
								
							}
							case 2:
							{
								l.LargestNumberOF4();
							}
							default:
								throw new IllegalArgumentException("Unexpected value: " + key);
							}*/
	}

}
