package task_5;

public class B extends A{
 //sub
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		
	}

}
