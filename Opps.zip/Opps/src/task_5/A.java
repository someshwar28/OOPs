package task_5;

public class A extends CalcAbs
{

	@Override
	void sum(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void div(int a, int b) {
		// TODO Auto-generated method stub
		
	}

}
