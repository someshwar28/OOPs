package task_5;

public class C extends B{
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		
	}


}
