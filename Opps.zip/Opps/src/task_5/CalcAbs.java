package task_5;

 public abstract class CalcAbs 
{
 
abstract void sum(int a, int b);
abstract void sub(int a, int b);
abstract void mul(int a, int b);
abstract void div(int a,int b);
}