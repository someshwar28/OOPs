package task_5;

public class D extends C
{
	void div(int a, int b) {
		// TODO Auto-generated method stub
		
	}
}
