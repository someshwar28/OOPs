package task_8;

import java.util.Date;

public class Mobile extends Electornics {

	public Mobile(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
